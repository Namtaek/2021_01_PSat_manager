<div align=center>
  
<i> "(멋진 말)" </i>

</div>

<div align=center>


</div>

## (자기 이름)

#### Hi there. 👋
#### Interested in (관심 분야)

### Education

- ```2015-2021``` Bachelor of Statistics, Sungkyunkwan University.

#### External activities

- ```2020.03-2021.06``` Statistical Analysis group P-SAT (Dept. of Statistics in Sungkyunkwan)
  - Time Series Analysis Team / Regression Analysis Team Leader / Group Manager

### COURSEWORK

#### Undergraduate

- Mathematics for Statistics / Matrix Algebra / Principles of Statistics
- Mathematical Statistics 1&2
- Regression Analysis 
- etc...


### Skills

#### Technical

- ...

#### Coding

- R (숙련도 적기)
  - (어떤 것을 할 수 있는지, 예를 들어 dplyr을 통한 전처리나 머신러닝 모델링 등)
- Python (숙련도 적기)
  - (어떤 것을 할 수 있는지, 예를 들어 pandas을 통한 전처리나 머신러닝 모델링 등)

